#pragma once

void BM(std::vector<std::pair<std::pair<size_t, size_t>, unsigned int>> const&, std::vector<unsigned int>&, bool const&);
